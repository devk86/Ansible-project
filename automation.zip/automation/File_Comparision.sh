#!/bin/bash
# Script to compare Source and target SMT output and generate compare file using diff
path_s="Source_SMT"
path_t="Target_SMT"
var_s=($(ls Source_SMT))
var_t=($(ls Target_SMT))
for ((i=0;i<=${#var_s[@]};i++));do
tmp_s=`echo ${var_s[i]} | awk -F '_' '{print $2}'`
tmp_t=`echo ${var_t[i]} | awk -F '_' '{print $2}'`
if [ $tmp_s == $tmp_t ]
then
	diff -y --suppress-common-lines $path_s/${var_s[i]} $path_t/${var_t[i]} > Comparision_SMT/comparision_smt_$tmp_s.txt 
else 
  	echo "Source file name ${var_s[i]} and Target file name ${var_t[i]} does not match"
fi
#echo ${var_s[i]}
#echo ${var_t[i]}
done
