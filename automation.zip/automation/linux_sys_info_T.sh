#!/bin/bash
main_fun() {
#
#ScriptName     : linux_sys_info.sh
##Author        : Prasanth Soman P S (prassoma@in.ibm.com)
#Version        : Initial Releaset
#Date           : 2-Jul-2018
#Usage          : Collecting Linux System Configuration
#Supported OS   : RHEL5 & RHEL6
#

# First, check whether we are running this in a Linux box and whether the distro is supported
OSCLASS="$(uname -s)"
if [ "${OSCLASS}" == "Linux" ]; then 
	if [ -f /etc/SuSE-release ]
	then OS_DIST=SLES
	     OS_Version=$(cat /etc/SuSE-release|head -1)
	elif [ -f /etc/redhat-release ]; then
		OS_DIST=$(cat /etc/redhat-release|awk '{print $1}')
		OS_Version=$(cat /etc/redhat-release)
		case ${OS_DIST} in
			CentOS) OS_DIST=CentOS;;
			Red) OS_DIST=RHEL;;
		esac
	else echo "This Linux distribution is NOT supported"; exit
	fi
else echo "${OSCLASS} NOT Supported"; exit
fi




tdate="$(date +%d%m%y-%H%M%S)"
hname=$(uname -n)
rhelv=${OS_Version}
kernv=$(uname -r)
cpucnt=$(grep processor /proc/cpuinfo |wc -l)
memt=$(free -lm|awk '/Mem/ {print $2}')
swapt=$(free -lm|awk '/Swap/ {print $2}')
uptm=$(uptime |awk '{print $3" "$4}'|sed 's/.$//')
loadavg=$(uptime |awk -F ":" '{print $NF}'|awk '{$1=$1}{ print }')

echo -e "\nSYSTEM INFORMATION"
echo "---------------------"
echo -e "Date                   :\t`date`"
echo -e "Host Name              :\t$hname"
echo -e "Operating System       :\t$rhelv"
echo -e "Current Kernel         :\t$kernv"
echo -e "Total No of CPUs       :\t$cpucnt"
echo -e "Total Memory           :\t$memt MB"
echo -e "Total Swap             :\t$swapt MB"
echo -e "Uptime                 :\t$uptm"
echo -e "Load average           :\t$loadavg"
echo -e "TimeZone               :\t`date +%Z`"
if bash vmware-toolbox-cmd >/dev/null 2>&1
then
        vmtool_ver=$(vmware-toolbox-cmd -v)
        echo -e "VMtools                :\t$vmtool_ver"
fi
echo -e "Total number of Disks                  :\t`fdisk -l 2>/dev/null|grep 'Disk /dev/sd'|wc -l`"
echo -e "Total number of FileSystems            :\t`df -hPT|grep -v 'Filesystem'|wc -l`"
echo -e "Total number of Logical Volumes        :\t`lvs|grep -v LSize|wc -l`"
echo -e "Total number of Volume Groups          :\t`vgs|grep -v VSize|wc -l`"
echo -e "Total number of Physical Volumes       :\t`pvs|grep -v PSize|wc -l`"
echo;echo
 pvs   --segments  -o pv_name,pv_size,seg_size,vg_name,lv_name,lv_size,seg_pe_ranges
  lvs -o +lv_size,lv_name

echo -e "\nMemory information"
echo "-----------------------"
free -lm
echo

echo -e "\nLogical CPU infomration "
echo "-----------------------------"
hash lscpu >/dev/null 2>&1 && lscpu || cat /proc/cpuinfo|egrep 'processor|model name|cpu MHz'
echo

echo -e "\nSwap device information "
echo "-----------------------------"
swapon -s
echo

echo -e "\nNIC Configuration "
echo "----------------------"
ifconfig -a
echo

echo -e "\nKernel Routing Table "
echo "--------------------------"
hash route >/dev/null 2>&1 && route -n || ip route show
echo

echo -e "\nFilesystem Information "
echo "----------------------------"
df -hPT
echo

echo -e "\nLogical Volume Information "
echo "--------------------------------"
lvs
echo

echo -e "\nVolume Group information "
echo "------------------------------"
vgs
echo

echo -e "\nPhysical Volume information "
echo "---------------------------------"
pvs
echo

echo -e "\nDisk Infomation "
echo "---------------------"
fdisk -l 2>/dev/null |grep 'Disk /dev/sd'
echo


echo -e "\nList listening ports"
echo "-------------------------"
if hash netstat >/dev/null 2>&1
then netstat -tulnp
else echo "netstat utility not available"
fi
echo

echo -e "\nListing Firewall configuration "
echo "------------------------------------"
iptables -L -n
iptables -t nat -L -n -v
echo

echo -e "\nChecking Selinux status "
echo "----------------------------"
hash getenforce >/dev/null 2>&1 && getenforce
echo

echo -e "\nChecking if multipath disks "
echo "---------------------------------"
hash multipath >/dev/null 2>&1 && multipath -ll
echo

echo -e "\nNTP status (ntpq -p)"
echo "------------------------"
#ntpq -p
echo

echo -e "\nDevice Mapper setup "
echo "-------------------------"
hash tree && dmsetup ls --tree && echo
dmsetup ls
echo

echo -e "\nListing Block Device attributes "
echo "-------------------------------------"
blkid
echo


echo -e "\nChecking NFS exports "
echo "--------------------------"
hash showmount >/dev/null 2>&1 && showmount -e && echo
if [ -s /etc/exports ]
then
        echo "Printing /etc/exports"
        echo "---------------------"
        cat /etc/exports
        echo
fi


echo -e "\nPrinting host list from /etc/hosts"
echo "--------------------------------------"
cat /etc/hosts
echo

echo -e "\nPrinting Filesystem Tab (/etc/fstab)"
echo "----------------------------------------"
cat /etc/fstab
echo

echo -e "\nPrinting SELinux Configuration"
echo "----------------------------------"
if [ -f /etc/sysconfig/selinux ]
then cat /etc/sysconfig/selinux
fi
echo

if [ -f /etc/sysconfig/network ]
then
	echo -e "\nPrinting /etc/sysconfig/network"
	echo "----------------------------------"
	cat /etc/sysconfig/network
fi
echo

echo -e "\nPrinting Network configurations"
echo "---------------------------------"

case $OS_DIST in
	SLES) nw_cfg_path=/etc/sysconfig/network ;;
	CentOS|RHEL) nw_cfg_path=/etc/sysconfig/network-scripts ;;
esac
	
for eth_dev in `ls ${nw_cfg_path}/ifcfg-*`
do
echo -e "\n${eth_dev}:"
cat ${eth_dev}
done

if ls -ld ${nw_cfg_path}/route-* >/dev/null 2>&1
then
        echo -e "\nPrinting Static Routes"
        echo "-------------------------"
        for static_route in `ls ${nw_cfg_path}/route-*`
        do
                echo -e "\n${static_route}:"
                cat ${static_route}
        done
        echo
fi

echo -e "\nPrinting NTP configuration "
echo "--------------------------------"
cat /etc/ntp.conf
echo

echo -e "\nPrinting DNS configuration "
echo "--------------------------------"
cat /etc/resolv.conf
echo

echo -e "\nPrinting Service Status "
echo "-----------------------------"
hash systemctl >/dev/null 2>&1 && systemctl list-units --type=service --no-pager || service --status-all
echo

echo -e "\nPrinting Service Activation list "
echo "--------------------------------------"
hash chkconfig >/dev/null 2>&1 && chkconfig --list
echo

echo -e "\n---------------------------------"
echo "Printing current Process Lists"
echo "---------------------------------"
echo -e "\n `ps auxww`"
echo "---------"
ps auxww
echo
echo -e "\n---------------------------------"
echo -e "\nPrinting Bigfix Status "
 rpm -qa|grep BESAgent|awk -F '-' '{print $1,$2}'
echo -e "\n---------------------------------"
echo -e "\nPrinting ITM Tivoli Status"
/opt/IBM/ITM/bin/./cinfo -i|awk -F ':' NR==4'{print "ITM Version "$3}'
echo -e "\nPrinting Dynatrace Configuration"
echo -e "\n `service oneagent status`"
echo -e "\n---------------------------------"
echo -e "\nPrinting Tripwire tool status"
 cd "/usr/local/tripwire/te/agent/bin"
echo -e "\n `./twdaemon status`"
echo -e "\n---------------------------------"
echo -e "\nPrinting MCAfee status"
/opt/McAfee/agent/bin/./cmdagent -i|awk NR==3'{print "McAfee Version " $2}'
echo -e "\n `/etc/init.d/cma status`"
echo -e "\n---------------------------------"
echo -e "\nPrinting DynaTrace status"
echo -e "\n `/opt/dynatrace/oneagent/./agent/initscripts/oneagent status|awk NR==3'{print $2,$3,$4,$5}'` "

echo -e "\nPrinting TSM Configuration "
echo "--------------------------------"
if [ -f /etc/tsm/dsm.sys ]
then
	echo -e "\nPrinting /etc/tsm/dsm.sys"
	echo "----------------------------------"
	cat /etc/tsm/dsm.sys
fi
echo

echo -e "\nPrinting TSM Domain configuration "
echo "---------------------------------------"
grep -i domain /var/cfengine/inputs/update.conf
echo



echo "------------------------------------------"
echo "|              FINISHED                  |"
echo "------------------------------------------"
}

main_fun  > /tmp/Target_`hostname -s`"_`date +%Y-%m-%d`.txt"


